import java.rmi.RemoteException;

import com.howtodoinjava.www.xml.school.StudentDetailsPortProxy;
import com.howtodoinjava.www.xml.school.StudentDetailsRequest;
import com.howtodoinjava.www.xml.school.StudentDetailsResponse;


public class MainClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		StudentDetailsPortProxy proxy = new StudentDetailsPortProxy();
		StudentDetailsRequest st = new StudentDetailsRequest();
		st.setName("raghu");
		
		try {
			StudentDetailsResponse  sr = proxy.studentDetails(st);
			System.out.println(sr.getStudent().getStandard());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
