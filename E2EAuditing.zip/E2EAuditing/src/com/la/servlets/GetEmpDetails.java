package com.la.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.la.accessor.EmployeeAccessor;
import com.la.entities.Employee;

public class GetEmpDetails extends HttpServlet{

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String no=req.getParameter("no");
		Employee employee=null;
		int empNo=Integer.parseInt(no);
		try {
			employee=new EmployeeAccessor().getEmployee(empNo);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		req.setAttribute("emp",employee );
		req.getRequestDispatcher("editEmp.jsp").forward(req, res);
	}
	
}
