package com.la.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.la.accessor.UserAccessor;
import com.la.customExc.UserNotFoundException;

public class LoginServlet extends HttpServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String page=null;
		int userId=0;
		HttpSession session=null;
		String userName=req.getParameter("user");
		String password=req.getParameter("pwd");
		//System.out.println(userName+" "+password);
		UserAccessor userAccessor=new UserAccessor();
		try {
			userId=userAccessor.getUser(userName, password);
			System.out.println(userId);
			session=req.getSession();
			session.setAttribute("currentloginUser", userId);
			page="home.jsp";
			
		} catch (UserNotFoundException | ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			page="login-error.jsp";
		}
		req.getRequestDispatcher(page).forward(req, res);
	}
}
