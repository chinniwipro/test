package com.la.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.la.accessor.EmployeeAccessor;
import com.la.entities.Employee;

public class ListEmployeesServlet extends HttpServlet{

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		List<Employee> employees=null;
		EmployeeAccessor accessor=null;
		accessor=new EmployeeAccessor();
		try {
			employees=accessor.getAllEmployees();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		req.setAttribute("emps", employees);
		req.getRequestDispatcher("showEmp.jsp").forward(req, res);
	}
	
}
