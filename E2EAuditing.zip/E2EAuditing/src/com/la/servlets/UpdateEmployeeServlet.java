package com.la.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.ws.Response;

import com.la.accessor.EmployeeAccessor;
import com.la.entities.Employee;

public class UpdateEmployeeServlet extends HttpServlet{
	int empNo=0;
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		EmployeeAccessor accessor=null;
		/*
		try{
		int empNo=Integer.parseInt(req.getParameter("eno"));
		}catch(NumberFormatException e){
			e.printStackTrace();
		}*/
		PrintWriter out=res.getWriter();
		String eno=req.getParameter("eno");
		int enoo=Integer.parseInt(eno);
		String firstName=req.getParameter("fn");
		String lastName=req.getParameter("ln");
		float sal=Float.parseFloat(req.getParameter("sal"));
		try{
			
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","dhanu","dhanu123");
		Statement stmt=con.createStatement();
		stmt.executeUpdate("update  empp set firstnm='"+firstName+"',lastnm='"+lastName+"',sal="+sal+" where empid="+enoo+"");
		out.println("<h1 style='color:blue'>update sucessfully...<h1>");
		
		}catch(Exception e){
			e.printStackTrace();
		}
		/*//HttpSession session=req.getSession(false);
		int userId=(int) session.getAttribute("currentloginUser");
		Employee employee=new Employee();
		employee.setEmpNo(enoo);
		employee.setFirstName(firstName); 
		employee.setLastname(lastName);
		employee.setSal(sal);
		accessor=new EmployeeAccessor();
			try {
				accessor.updateEmployee(employee);
				res.getWriter().println("<h1>updated successfully</h1>");
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
	
		
	}
	
}
