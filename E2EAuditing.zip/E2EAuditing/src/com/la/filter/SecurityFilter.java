package com.la.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

public class SecurityFilter implements Filter {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		//System.out.println("filter");
		int uid=0;
		HttpSession httpSession = ((HttpServletRequest) req).getSession(false);
		
		if (httpSession != null) {
			//System.out.println("session");
		 uid =  (int) httpSession.getAttribute("currentloginUser");
		// System.out.println(uid);
		}
			
			if (uid <= 0) {
				((HttpServletResponse) res).sendRedirect("login.jsp");
				return;
			}
			
		
		chain.doFilter(req, res);
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
