package com.la.accessor;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.la.customExc.UserNotFoundException;

public class UserAccessor {
	public int getUser(String user,String pwd) throws UserNotFoundException, ClassNotFoundException, SQLException{
		int userId=0;
		Connection con=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "dhanu", "dhanu123");
		preparedStatement=con.prepareStatement("select USER_ID from users where username=? and password=?");
		preparedStatement.setString(1, user);
		preparedStatement.setString(2, pwd);
		resultSet=preparedStatement.executeQuery();
		if(resultSet.next()){
			userId=resultSet.getInt(1);
		}else{
			throw new UserNotFoundException();
		}
		
		return userId;
	}
}
