package com.la.accessor;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.la.entities.Employee;

public class GetEmployeeDetailsServlet extends HttpServlet{

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		int empNo=Integer.parseInt(req.getParameter("no"));
		Employee employee=null;
		EmployeeAccessor accessor=new EmployeeAccessor();
		try {
			employee=accessor.getEmployee(empNo);
			req.setAttribute("emp", employee);
			req.getRequestDispatcher("editemp.jsp").forward(req, res);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
