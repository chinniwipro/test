package com.la.accessor;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.la.entities.Audit;
import com.la.entities.Employee;

public class EmployeeAccessor {
	public Employee getEmployee(int eno) throws ClassNotFoundException, SQLException {
		Employee employee = null;
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "dhanu", "dhanu123");
		preparedStatement = con.prepareStatement("select * from Emp where empId=?");
		preparedStatement.setInt(1, eno);
		resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			employee = new Employee();
			employee.setEmpNo(resultSet.getInt(1));
			employee.setFirstName(resultSet.getString(2));
			employee.setLastname(resultSet.getString(3));
			employee.setSal(resultSet.getFloat(4));

		}

		return employee;
	}

	public List<Employee> getAllEmployees() throws ClassNotFoundException, SQLException {
		List<Employee> employees = null;
		employees = new ArrayList<Employee>();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "dhanu", "dhanu123");
		preparedStatement = con.prepareStatement("select empid,firstnm,lastnm,sal from employee");
		resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			Employee employee = new Employee();
			employee.setEmpNo(resultSet.getInt(1));
			employee.setFirstName(resultSet.getString(2));
			employee.setLastname(resultSet.getString(3));
			employee.setSal(resultSet.getFloat(4));
			employees.add(employee);

		}
		return employees;
	}

	public void updateEmployee(Employee employee) throws ClassNotFoundException, SQLException {
		List<Audit> audits = new ArrayList<Audit>();
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Employee oEmp = getEmployee(employee.getEmpNo());
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "dhanu", "dhanu123");
		con.setAutoCommit(false);
		preparedStatement = con
				.prepareStatement("update Employee set firstnm=?,lastnm=?,sal=? where empid='"+employee.getEmpNo()+"'");
		preparedStatement.setString(1, employee.getFirstName());
		preparedStatement.setString(2, employee.getLastname());
		preparedStatement.setFloat(3, employee.getSal());
		//preparedStatement.setString(4, employee.getLastModifiedBy());
		//preparedStatement.setTimestamp(5, employee.getLastModifiedDt());
		preparedStatement.setInt(4, employee.getEmpNo());
		preparedStatement.executeUpdate();
		con.commit();
		if (employee.getFirstName().equals(oEmp.getFirstName()) == false) {
			Audit audit = new Audit();
			audit.setTable("Employee");
			audit.setColumn("firstnm");
			audit.setOpType("update");
			audit.setOldValue(oEmp.getFirstName());
			audit.setNewValue(employee.getFirstName());
			audit.setModBy(employee.getEmpNo() + " " + employee.getFirstName());
			// audit.setModDt(new
			// SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date()));
			audit.setModDt(new Timestamp(Calendar.getInstance().getTime().getTime()));
			audits.add(audit);
		}
		if (employee.getLastname().equals(oEmp.getLastname()) == false) {
			Audit audit = new Audit();
			audit.setTable("Employee");
			audit.setColumn("lastnm");
			audit.setOpType("update");
			audit.setOldValue(oEmp.getLastname());
			audit.setNewValue(employee.getLastname());
			audit.setModBy(employee.getEmpNo() + " " + employee.getFirstName());
			// audit.setModDt(new
			// SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date()));
			audit.setModDt(new Timestamp(Calendar.getInstance().getTime().getTime()));
			audits.add(audit);
		}
		if (employee.getSal() != oEmp.getSal()) {
			Audit audit = new Audit();
			audit.setTable("Employee");
			audit.setColumn("firstnm");
			audit.setOpType("update");
			audit.setOldValue(oEmp.getSal() + "");
			audit.setNewValue(employee.getSal() + "");
			audit.setModBy(employee.getEmpNo() + " " + employee.getFirstName());
			// audit.setModDt(new
			// SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date()));
			audit.setModDt(new Timestamp(Calendar.getInstance().getTime().getTime()));
			audits.add(audit);
		}
		AuditAccessor auditAccessor=new AuditAccessor();
		auditAccessor.save(audits);
	}
}
