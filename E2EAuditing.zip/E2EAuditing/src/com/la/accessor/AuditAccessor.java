package com.la.accessor;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.la.entities.Audit;
import com.la.entities.Employee;

public class AuditAccessor {
	public void save(List<Audit> audits) throws ClassNotFoundException,
			SQLException {
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection(
				"jdbc:oracle:thin:@localhost:1521:xe", "dhanu", "dhanu123");
		for (Audit audit : audits) {
			preparedStatement = con
					.prepareStatement("insert into audittab(TABLENAME,COLUMNNAME,TYPEOFOPERATION,OLDVALUE,NEWVALUE,MODIFIEDBY,MODIFIEDDT) values(?,?,?,?,?,?,?)");
			preparedStatement.setString(1, audit.getTable());
			preparedStatement.setString(2, audit.getColumn());
			preparedStatement.setString(3, audit.getOpType());
			preparedStatement.setString(4, audit.getOldValue());
			preparedStatement.setString(5, audit.getNewValue());
			preparedStatement.setString(6, audit.getModBy());
			preparedStatement.setTimestamp(7, audit.getModDt());
			preparedStatement.executeUpdate();

		}
	}
}
