package com.ji.bean;

import javax.ws.rs.CookieParam;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

public class Criteria {
	@PathParam("manuf")
	private String manufacturer;
	@PathParam("type")
	private String type;
	@QueryParam("year")
	private int year;
	@CookieParam("city")
	private String city;
	@QueryParam("color")
	private String color;
	@QueryParam("fuel")
	private String fuelType;
	@MatrixParam("model")
	private String model;

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getFuelType() {
		return fuelType;
	}

	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	@Override
	public String toString() {
		return "Criteria [manufacturer=" + manufacturer + ", type=" + type + ", year=" + year + ", city=" + city
				+ ", color=" + color + ", fuelType=" + fuelType + ", model=" + model + "]";
	}

}
