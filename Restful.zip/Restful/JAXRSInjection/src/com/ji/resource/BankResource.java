package com.ji.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/icici")
public class BankResource {
	@GET
	@Path("/account/{accountNo: \\d{3}}-{type}")
	@Produces(MediaType.TEXT_PLAIN)
	public String getAccountInfo(@PathParam("accountNo") int accountNo, @PathParam("type") String accountType) {
		return "accNo : " + accountNo + " acType : " + accountType + " holderName : john";
	}

	@GET
	@Path("/{accountNo}/balance")
	@Produces(MediaType.TEXT_PLAIN)
	public String getBalanace(@PathParam("accountNo") int accountNo) {
		return "accNo : " + accountNo + " balance : 394";
	}
}
