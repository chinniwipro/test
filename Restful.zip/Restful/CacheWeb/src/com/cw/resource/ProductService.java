package com.cw.resource;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.EntityTag;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import com.cw.dto.Product;

@Path("/product")
public class ProductService {
	private Map<Integer, Product> productMap;

	public ProductService() {
		productMap = new HashMap<Integer, Product>();
	}

	@PUT
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.TEXT_PLAIN)
	public Response addProduct(Product product) throws URISyntaxException {
		Response response = null;

		if (productMap.containsKey(product.getProductCode()) == false) {
			response = Response.created(new URI("/" + product.getProductCode() + "/info"))
					.entity(Entity.entity("product inserted", MediaType.TEXT_PLAIN)).build();
		} else {
			response = Response.ok("product updated").build();
		}
		productMap.put(product.getProductCode(), product);
		return response;
	}

	@GET
	@Produces(MediaType.APPLICATION_XML)
	@Path("/{productCode}/info")
	public Response getProduct(@PathParam("productCode") int productCode, @Context Request request) {
		Product product = null;
		EntityTag eTag = null;
		ResponseBuilder builder = null;

		if (productMap.containsKey(productCode) == false) {
			throw new NotFoundException("resource not found");
		}
		product = productMap.get(productCode);
		eTag = new EntityTag(String.valueOf(product.hashCode()));
		// check with request eTag with server eTag
		builder = request.evaluatePreconditions(eTag);
		// if both ETag matches, the builder will be created with not-modified
		// header
		if (builder != null) {
			return builder.build();
		}
		CacheControl cc = new CacheControl();
		cc.setMaxAge(2000);
		return Response.ok(product).tag(eTag).cacheControl(cc).build();
	}
}
