package com.cw.application;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.cw.resource.ProductService;

@ApplicationPath("/api")
public class CWApplication extends Application {
	protected Set<Object> singletons;

	public CWApplication() {
		singletons = new HashSet<Object>();

		singletons.add(new ProductService());
	}

	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}

}
