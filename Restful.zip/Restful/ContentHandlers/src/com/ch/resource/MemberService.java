package com.ch.resource;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.StreamingOutput;

@Path("/member")
public class MemberService {
	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.TEXT_PLAIN)
	@Path("/reg-in")
	public StreamingOutput registerMember(InputStream in) throws IOException {
		int c = 0;
		StringBuffer buffer = null;

		try {
			buffer = new StringBuffer();
			while ((c = in.read()) != -1) {
				buffer.append((char) c);
			}
		} finally {
			in.close();
		}

		final String response = buffer.toString();
		return new StreamingOutput() {
			@Override
			public void write(OutputStream os) throws IOException, WebApplicationException {
				os.write(response.getBytes());
				os.close();
			}
		};
	}

	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/reg-reader")
	public String registerUser(Reader reader) throws IOException {
		StringBuffer buffer = new StringBuffer();
		int c = 0;

		try {
			while ((c = reader.read()) != -1) {
				buffer.append((char) c);
			}
		} finally {
			reader.close();
		}
		return buffer.toString();
	}

	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/reg-str")
	public String registerUser(String body) {
		return body;
	}

	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/reg-byte")
	public byte[] registerUser(byte[] body) {
		return body;
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_OCTET_STREAM)
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	@Path("/reg-file")
	public File registerBuilkUsers(File file) {
		return file;
	}
}















