package com.cpc.resource;

import javax.ws.rs.GET;

import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.Path;

import com.cpc.dto.Address;

@Path("/amazon")
public class Amazon {
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/pickup")
	public String pickup(@QueryParam("address") Address address) {
		return address.toString();
	}
}
