package com.ac.resource;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.StreamingOutput;

import com.ac.dto.Account;

abstract public class FreechargeWallet {
	@POST
	@Consumes({ MediaType.APPLICATION_XML, MediaType.TEXT_PLAIN })
	@Produces({ MediaType.APPLICATION_XML, MediaType.TEXT_PLAIN })
	public StreamingOutput register(InputStream in) {
		Account account = null;

		account = buildAccount(in);
		account.setAccountNo(UUID.randomUUID().toString());
		// apply logic
		final byte[] responseData = buildRegistrationResponse(account);
		return new StreamingOutput() {
			@Override
			public void write(OutputStream os) throws IOException, WebApplicationException {
				os.write(responseData);
				os.close();
			}
		};
	}

	abstract protected Account buildAccount(InputStream in);

	abstract protected byte[] buildRegistrationResponse(Account account);
}
