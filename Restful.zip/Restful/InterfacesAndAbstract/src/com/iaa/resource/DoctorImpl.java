package com.iaa.resource;

public class DoctorImpl implements Doctor {
	@Override
	public String getContactDetails(String doctor) {
		return "doctor : " + doctor + " mobile : 39330";
	}
}
