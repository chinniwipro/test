package com.sw.resource;

import javax.ws.rs.ForbiddenException;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.SecurityContext;

@Path("/stock")
public class Stock {
	@Context
	private SecurityContext securityContext;

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/{stockName}/price")
	public float getStockPrice(@PathParam("stockName") String stockName) {
		if (securityContext.isUserInRole("admin") == true) {
			// execute
		}
		return 3.34f;
	}
}







