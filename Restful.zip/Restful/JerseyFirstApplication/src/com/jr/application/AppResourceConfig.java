package com.jr.application;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;

import com.jr.resource.ProductResource;

@ApplicationPath("/api")
public class AppResourceConfig extends ResourceConfig {
	public AppResourceConfig() {
		registerInstances(new ProductResource());
	}
}
