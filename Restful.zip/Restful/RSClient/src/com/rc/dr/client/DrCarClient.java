package com.rc.dr.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

public class DrCarClient {
	private final String BASE_URI = "http://localhost:8081/JAXRSInjection/api/drCar";

	public void saleReport(String model, String type) {
		ClientBuilder builder = ClientBuilder.newBuilder();
		Client client = builder.build();

		WebTarget target = client.target(BASE_URI).path("/sales/{model}/{type}/report");
		target = target.resolveTemplate("model", model);
		target = target.resolveTemplate("type", type);

		Response response = target.request().get();
		if (response.getStatus() == Status.OK.getStatusCode()) {
			String body = response.readEntity(String.class);
			System.out.println(body);
		} else {
			System.out.println(response.getStatus());
		}
		client.close();
	}

	public void getQuote(String model, String manuf, int year, String modelColor, String manufColor) {
		ClientBuilder builder = ClientBuilder.newBuilder();
		Client client = builder.build();

		/*
		 * WebTarget target = client.target(BASE_URI).path("/quote/{model}");
		 * target = target.matrixParam("color", modelColor); target =
		 * target.path("/{manuf}"); target = target.matrixParam("color",
		 * manufColor); target = target.path("/{year}");
		 * 
		 * target = target.resolveTemplate("model", model); target =
		 * target.resolveTemplate("manuf", manuf); target =
		 * target.resolveTemplate("year", year);
		 * 
		 * 
		 * 
		 * 
		 * Response response = target.request().get(); if(response.getStatus()
		 * == Status.OK.getStatusCode()) { String body =
		 * response.readEntity(String.class); System.out.println(body); }
		 */

		String body = client.target(BASE_URI).path("/quote/{model}").resolveTemplate("model", model)
				.matrixParam("color", modelColor).path("/{manuf}").resolveTemplate("manuf", manuf)
				.matrixParam("color", manufColor).path("/{year}").resolveTemplate("year", year).request()
				.get(String.class);
		System.out.println(body);

	}

	public void enquire(String name, String mobile, String email) {
		String body = ClientBuilder.newClient().target(BASE_URI).path("/enquire/{name}").resolveTemplate("name", name)
				.path("/{mobile}").resolveTemplate("mobile", mobile).queryParam("email", email).request()
				.get(String.class);
		System.out.println(body);
	}

	public void getClientId(String username) {
		String body = ClientBuilder.newClient().target(BASE_URI).path("/clientId").request()
				.header("username", username).get(String.class);
		System.out.println(body);
	}

	public void search(String type, String manuf, int year, String color, String city) {
		String body = ClientBuilder.newClient().target(BASE_URI).path("/{type}").resolveTemplate("type", type)
				.path("/{manuf}").resolveTemplate("manuf", manuf).matrixParam("color", color)
				.matrixParam("fuel", "diesel").path("/{year}").resolveTemplate("year", year).request()
				.cookie(new NewCookie("city", city)).get(String.class);
		System.out.println(body);
	}

	public void addCar(String modelNo, String type, String manuf, int year) {
		MultivaluedMap<String, String> formParam = new MultivaluedHashMap<String, String>();
		formParam.putSingle("modelNo", modelNo);
		formParam.putSingle("type", type);
		formParam.putSingle("manuf", manuf);
		formParam.putSingle("year", String.valueOf(year));

		Response response = ClientBuilder.newClient().target(BASE_URI).path("/add-car").request()
				.post(Entity.entity(formParam, MediaType.APPLICATION_FORM_URLENCODED));
		if (response.getStatus() == Status.OK.getStatusCode()) {
			String body = response.readEntity(String.class);
			System.out.println(body);
		}
	}

	public void addCarForm(String modelNo, String type, String manuf, int year) {
		Form form = new Form();
		form.param("modelNo", modelNo);
		form.param("type", type);
		form.param("manuf", manuf);
		form.param("year", String.valueOf(year));

		Response response = ClientBuilder.newClient().target(BASE_URI).path("/add-car").request()
				.post(Entity.form(form));
		if(response.getStatus() == Status.OK.getStatusCode()) {
			response.bufferEntity();
			String body = response.readEntity(String.class);
			System.out.println(body);
		}
	}

}







