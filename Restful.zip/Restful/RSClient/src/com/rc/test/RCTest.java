package com.rc.test;

import com.rc.dr.client.DrCarClient;

public class RCTest {
	public static void main(String[] args) {
		DrCarClient drClient = new DrCarClient();
		//drClient.saleReport("wagnor", "hatchback");
		// drClient.getQuote("swift", "maruthi", 2016, "red", "orange");
		
		//drClient.enquire("john", "039405", "john@gmail.com");
		// drClient.getClientId("john");
		//drClient.search("sedan", "hyundai", 2015, "red", "hyderabad");
		
		//drClient.addCar("mo398", "sedan", "maruthi", 2016);
		drClient.addCarForm("M039", "sedan", "maruthi", 2017);
	}
}














