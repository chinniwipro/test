import java.rmi.RemoteException;

import javax.xml.namespace.QName;
import javax.xml.rpc.Call;
import javax.xml.rpc.ParameterMode;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.ServiceFactory;

import com.howtodoinjava.www.xml.school.StudentDetailsResponse;

public class WebClient {

	private static final String SERVICE_NM = "StudentDetailsPortService";
	private static final String PORT_NM = "StudentDetailsPort";
	private static final String OPERATION_NM = "StudentDetails";
	private static final String TARGET_NMSPC = "http://www.howtodoinjava.com/xml/school";
	private static final String TYPE_NMSPC = "http://www.w3.org/2001/XMLSchema";
	private static final String TARGET_ADDRESS = "http://localhost:2121/service/studentDetailsWsdl.wsdl";
	private static final String SOAP_ACTION = "";
	private static final String ENCODING_URI = "http://schemas.xmlsoap.org/soap/encoding/";

	public static void main(String[] args) throws ServiceException,
			RemoteException {
		ServiceFactory sfactory = ServiceFactory.newInstance();
		Service studentDetailsPortService = sfactory.createService(new QName(
				TARGET_NMSPC, SERVICE_NM));
		Call studentDetailsResponse = studentDetailsPortService
				.createCall(new QName(TARGET_NMSPC, PORT_NM));

		// define the place holder's to represent request
		studentDetailsResponse.setOperationName(new QName(TARGET_NMSPC,
				OPERATION_NM));
		studentDetailsResponse.addParameter("String_1", new QName(TYPE_NMSPC,
				"string"), ParameterMode.IN);
		studentDetailsResponse.setReturnType(new QName(TARGET_NMSPC,
				"StudentDetailsResponse"));

		// transport information in access the method
		studentDetailsResponse.setTargetEndpointAddress(TARGET_ADDRESS);
		studentDetailsResponse.setProperty(Call.SOAPACTION_URI_PROPERTY,
				SOAP_ACTION);
		studentDetailsResponse.setProperty(Call.ENCODINGSTYLE_URI_PROPERTY,
				ENCODING_URI);
		studentDetailsResponse.setProperty(Call.SOAPACTION_USE_PROPERTY, true);

		StudentDetailsResponse name = (StudentDetailsResponse) studentDetailsResponse
				.invoke(new Object[] { "Kajal" });
		System.out.println("price : " + name);

	}
}
