package com.howtodoinjava.www.xml.school;

public class StudentDetailsPortProxy implements com.howtodoinjava.www.xml.school.StudentDetailsPort {
  private String _endpoint = null;
  private com.howtodoinjava.www.xml.school.StudentDetailsPort studentDetailsPort = null;
  
  public StudentDetailsPortProxy() {
    _initStudentDetailsPortProxy();
  }
  
  public StudentDetailsPortProxy(String endpoint) {
    _endpoint = endpoint;
    _initStudentDetailsPortProxy();
  }
  
  private void _initStudentDetailsPortProxy() {
    try {
      studentDetailsPort = (new com.howtodoinjava.www.xml.school.StudentDetailsPortServiceLocator()).getStudentDetailsPortSoap11();
      if (studentDetailsPort != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)studentDetailsPort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)studentDetailsPort)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (studentDetailsPort != null)
      ((javax.xml.rpc.Stub)studentDetailsPort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.howtodoinjava.www.xml.school.StudentDetailsPort getStudentDetailsPort() {
    if (studentDetailsPort == null)
      _initStudentDetailsPortProxy();
    return studentDetailsPort;
  }
  
  public com.howtodoinjava.www.xml.school.StudentDetailsResponse studentDetails(com.howtodoinjava.www.xml.school.StudentDetailsRequest studentDetailsRequest) throws java.rmi.RemoteException{
    if (studentDetailsPort == null)
      _initStudentDetailsPortProxy();
    return studentDetailsPort.studentDetails(studentDetailsRequest);
  }
  
  
}