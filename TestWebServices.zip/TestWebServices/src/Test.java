import java.io.File;
import java.rmi.RemoteException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.rpc.ServiceException;

import org.apache.axis.AxisFault;

import com.howtodoinjava.www.xml.school.StudentDetailsPortSoap11Stub;
import com.howtodoinjava.www.xml.school.StudentDetailsRequest;
import com.howtodoinjava.www.xml.school.StudentDetailsResponse;


public class Test {
	public static void main(String[] args) throws ServiceException, RemoteException {

		StudentDetailsRequest req=(StudentDetailsRequest) unmarshallXML("E:\\Betterpractice\\FRAMEWORKS\\WebServices\\ApacheAxis2\\TestWebServices\\src\\resources\\test.xml",StudentDetailsRequest.class);
		System.out.println("result : "+req.getName());
		StudentDetailsPortSoap11Stub stub=new StudentDetailsPortSoap11Stub();
		StudentDetailsResponse res=stub.studentDetails(req);
		System.out.println("response :"+res.getStudent().getName());
		
	}
	
	public static Object unmarshallXML(String XmlPath,Class claz)
			throws ServiceException {
		Object result=null;
		 try {  
			   
		        File file = new File(XmlPath);  
		        JAXBContext jaxbContext = JAXBContext.newInstance(claz);  
		   
		        Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();  
		         result= jaxbUnmarshaller.unmarshal(file);  
		          
		      } catch (JAXBException e) {  
		        e.printStackTrace();  
		      }  
		 return result;
	}
}
