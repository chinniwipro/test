import java.io.File;
import java.rmi.RemoteException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.rpc.ServiceException;
import javax.xml.ws.WebServiceRef;

import com.howtodoinjava.www.xml.school.StudentDetailsPort;
import com.howtodoinjava.www.xml.school.StudentDetailsPortService;
import com.howtodoinjava.www.xml.school.StudentDetailsPortServiceLocator;
import com.howtodoinjava.www.xml.school.StudentDetailsPortSoap11Stub;
import com.howtodoinjava.www.xml.school.StudentDetailsRequest;
import com.howtodoinjava.www.xml.school.StudentDetailsResponse;


public class Client {

	@WebServiceRef(wsdlLocation="http://localhost:2121/service/studentDetailsWsdl.wsdl")
	static StudentDetailsPortService service;
	public static void main(String[] args) throws ServiceException, RemoteException {
		service=new StudentDetailsPortServiceLocator();
		StudentDetailsPort stub= service.getStudentDetailsPortSoap11();
		StudentDetailsRequest req=(StudentDetailsRequest) unmarshallXML("E:\\Betterpractice\\FRAMEWORKS\\WebServices\\ApacheAxis2\\TestWebServices\\src\\resources\\test.xml",StudentDetailsRequest.class);
		System.out.println("result : "+req.getName());
	
		StudentDetailsResponse  res= stub.studentDetails(req);
		
		System.out.println("response :"+res.getStudent().getName());
		
	}
	
	public static Object unmarshallXML(String XmlPath,Class claz)
			throws ServiceException {
		Object result=null;
		 try {  
			   
		        File file = new File(XmlPath);  
		        JAXBContext jaxbContext = JAXBContext.newInstance(claz);  
		   
		        Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();  
		         result= jaxbUnmarshaller.unmarshal(file);  
		          
		      } catch (JAXBException e) {  
		        e.printStackTrace();  
		      }  
		 return result;
	}
}
