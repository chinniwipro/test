package com.cch.readers;

import java.io.IOException;
import java.io.InputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.Consumes;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.Provider;

import com.cch.annotation.KeyValuedType;

@Provider
@Consumes(MediaType.TEXT_PLAIN)
public class KeyValuedMessageBodyReader implements MessageBodyReader<Object> {

	@Override
	public boolean isReadable(Class<?> classType, Type rawType, Annotation[] annotations, MediaType mediaType) {
		if (classType.isAnnotationPresent(KeyValuedType.class)) {
			return true;
		}
		return false;
	}

	@Override
	public Object readFrom(Class<Object> classType, Type rawType, Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, String> reqHeaders, InputStream in) throws IOException, WebApplicationException {
		Object obj = null;
		String rawData = null;
		Map<String, String> requestDataMap = null;

		rawData = extractData(in);
		requestDataMap = buildRequestDataMap(rawData);
		obj = bindRequestData(classType, requestDataMap);

		return obj;
	}

	private String extractData(InputStream in) {
		int c = 0;
		StringBuffer buffer = null;

		buffer = new StringBuffer();
		try {
			try {
				while ((c = in.read()) != -1) {
					buffer.append((char) c);
				}
			} finally {
				in.close();
			}
		} catch (IOException e) {
			throw new WebApplicationException(e);
		}
		return buffer.toString();
	}

	private Map<String, String> buildRequestDataMap(String rawData) {
		Map<String, String> requestDataMap = null;
		String[] pairedTokens = null;

		requestDataMap = new HashMap<String, String>();
		pairedTokens = rawData.split(";");
		for (String pair : pairedTokens) {
			String[] keyValueTokens = pair.split("=");
			requestDataMap.put(keyValueTokens[0], keyValueTokens[1]);
		}
		return requestDataMap;
	}

	private Object bindRequestData(Class<?> classType, Map<String, String> requestDataMap) {
		Object obj = null;
		Method method = null;
		String attributeValue = null;
		Set<String> attributeNames = null;

		try {
			// create the object of classType (for e.g. MemberShip)
			obj = classType.newInstance();
			attributeNames = requestDataMap.keySet();
			for (String attributeName : attributeNames) {
				attributeValue = requestDataMap.get(attributeName);
				method = getMethod("set" + attributeName, classType);
				method.invoke(obj, attributeValue);
			}

		} catch (Exception e) {
			throw new WebApplicationException(e);
		}
		return obj;
	}

	private Method getMethod(String methodName, Class<?> classType) {
		Method[] methods = null;
		Method rMethod = null;

		methods = classType.getDeclaredMethods();
		for (Method method : methods) {
			if (method.getName().equalsIgnoreCase(methodName)) {
				rMethod = method;
				break;
			}
		}
		return rMethod;
	}

}
