package com.cch.resource;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cch.dto.CabRequest;
import com.cch.dto.AccountInfo;
import com.cch.dto.Membership;
import com.cch.dto.Trip;

@Path("/uber")
public class Uber {

	@POST
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/trip")
	public Trip book(CabRequest request) {
		Trip trip = null;

		trip = new Trip();
		trip.setTripNo(request.getMemberNo() + "-T");
		trip.setFare(6);
		trip.setAuthCode(request.getDest());
		trip.setEstimatedAmount(399);

		return trip;
	}

	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public AccountInfo register(Membership memberShip) {
		AccountInfo accountInfo = null;

		accountInfo = new AccountInfo();
		accountInfo.setMemberNo("M3830");
		accountInfo.setUsername(memberShip.getUsername());
		accountInfo.setMobile(memberShip.getMobile());
		accountInfo.setMemberType("Member");

		return accountInfo;
	}
}
