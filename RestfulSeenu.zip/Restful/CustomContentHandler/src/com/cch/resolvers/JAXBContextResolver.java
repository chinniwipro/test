package com.cch.resolvers;

import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import com.cch.dto.CabRequest;
import com.cch.dto.Trip;

@Provider
@Produces(MediaType.APPLICATION_XML)
public class JAXBContextResolver implements ContextResolver<JAXBContext> {
	private JAXBContext jContext;

	public JAXBContextResolver() {
		try {
			this.jContext = JAXBContext.newInstance(new Class[] { CabRequest.class, Trip.class });
		} catch (JAXBException e) {
			throw new WebApplicationException(e);
		}
	}

	@Override
	public JAXBContext getContext(Class<?> classType) {
		if (classType.isAssignableFrom(CabRequest.class) || classType.isAssignableFrom(Trip.class)) {
			return jContext;
		}
		return null;

	}

}
