package com.cch.writers;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Type;

import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyWriter;
import javax.ws.rs.ext.Provider;

import com.cch.annotation.KeyValuedType;

@Provider
@Produces(MediaType.TEXT_PLAIN)
public class KeyValuedMessageBodyWriter implements MessageBodyWriter<Object> {

	@Override
	public long getSize(Object obj, Class<?> classType, Type rawType, Annotation[] annotations, MediaType mediaType) {
		return 0;
	}

	@Override
	public boolean isWriteable(Class<?> classType, Type rawType, Annotation[] annotations, MediaType mediaType) {
		if (classType.isAnnotationPresent(KeyValuedType.class)) {
			return true;
		}
		return false;
	}

	@Override
	public void writeTo(Object obj, Class<?> classType, Type rawType, Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, Object> respHeader, OutputStream os) throws IOException, WebApplicationException {
		String respData = null;

		respData = getKeyValuedTypeData(obj);
		os.write(respData.getBytes());
		os.close();
	}

	private String getKeyValuedTypeData(Object obj) {
		StringBuffer buffer = null;
		String attributeName = null;
		String attributeValue = null;
		Method getterMethod = null;
		Class<?> classType = null;
		Field[] fields = null;
		boolean isFirst = true;

		try {
			buffer = new StringBuffer();
			classType = obj.getClass();
			fields = classType.getDeclaredFields();
			for (Field field : fields) {
				attributeName = field.getName();
				getterMethod = getMethod("get" + attributeName, classType);
				attributeValue = (String) getterMethod.invoke(obj, null);
				if (isFirst) {
					buffer.append(attributeName).append("=").append(attributeValue);
					isFirst = false;
				} else {
					buffer.append(";").append(attributeName).append("=").append(attributeValue);
				}
			}
		} catch (Exception e) {
			throw new WebApplicationException(e);
		}
		return buffer.toString();
	}

	private Method getMethod(String methodName, Class<?> classType) {
		Method[] methods = null;
		Method rMethod = null;

		methods = classType.getDeclaredMethods();
		for (Method method : methods) {
			if (method.getName().equalsIgnoreCase(methodName)) {
				rMethod = method;
				break;
			}
		}
		return rMethod;
	}
}
