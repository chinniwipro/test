package com.jr.application;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.jr.resource.ProductResource;

/*@ApplicationPath("/api")*/
public class MyApplication extends Application {
	private Set<Object> singletons;

	public MyApplication() {
		singletons = new HashSet<Object>();
		singletons.add(new ProductResource());
	}

	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}

}
