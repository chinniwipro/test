package com.refa.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

@Path("/plan")
public class PlanResource {
	@GET
	@Produces("text/plain")
	public String getPlanDetails(@QueryParam("planNo") int planNo) {
		return "plan - " + planNo + " hash : " + this.hashCode();
	}
}
