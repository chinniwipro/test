package com.refa.application;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.refa.resource.PlanResource;

@ApplicationPath("/api")
public class ResteasyFirstApplication extends Application {
	private Set<Object> singletons;
	private Set<Class<?>> classes;

	public ResteasyFirstApplication() {
		System.out.println("ResteasyFirstApplication()");
		singletons = new HashSet<Object>();
		classes = new HashSet<Class<?>>();

		singletons.add(new PlanResource());
	}

	public Set<Object> getSingletons() {
		System.out.println("getSingletons()");
		return singletons;
	}

	@Override
	public Set<Class<?>> getClasses() {
		System.out.println("getClasses()");
		return classes;
	}

}
