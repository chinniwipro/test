package com.cw.resource;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/bluedart")
public class BluedartCourier {
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/{awbNo}/status")
	public Response getCourierStatus(@PathParam("awbNo") String awbNo) {
		Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
		calendar.set(2017, 05, 03, 0, 0, 0);
		Date expiresDate = calendar.getTime();

		return Response.ok("awbNo : " + awbNo + " status : in-transit").expires(expiresDate).build();
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/{source}/{dest}/rate")
	public Response getRegularCourierRate(@PathParam("source") String source, @PathParam("dest") String destination) {
		CacheControl cc = null;

		cc = new CacheControl();
		cc.setMaxAge(1000 * 60);
		cc.setMustRevalidate(false);

		return Response.ok("sourc	e : " + source + " - dest : " + destination + " charges : 50").cacheControl(cc)
				.build();
	}

}








