package com.tp.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/product/{product}/{manuf}")
public class ProductResource {
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getProducts(@PathParam("product") String productName, @PathParam("manuf") String manufacturer) {
		return "product : " + productName + " manuf : " + manufacturer;
	}

}
