package com.bu.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/uber")
public class UberRide {
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/estimate")
	public float getEstimatedCost(@QueryParam("source") String source, @QueryParam("dest") String destination) {
		return 353;
	}

	@GET
	@Path("/rate")
	@Produces(MediaType.TEXT_PLAIN)
	public float getRatePerKm(@QueryParam("area") String area) {
		return 23;
	}
}
