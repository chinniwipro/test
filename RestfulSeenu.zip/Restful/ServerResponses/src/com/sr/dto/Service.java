package com.sr.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "service")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Service")
public class Service {
	protected String serviceName;
	protected boolean enabled;

	public Service(String serviceName, boolean enabled) {
		this.serviceName = serviceName;
		this.enabled = enabled;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

}
