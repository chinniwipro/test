package com.sr.resource;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

import com.sr.dto.Account;
import com.sr.dto.Receipt;
import com.sr.dto.Service;
import com.sr.dto.TransferDetails;
import com.sr.errors.Errors;
import com.sr.exception.AccountNotFoundException;

@Path("/netbanking")
public class Netbanking {

	@PUT
	@Produces("text/plain")
	@Path("/subsribe/{accountno}/{mobile}")
	public Response subscribe(@PathParam("accountno") String accountno, @PathParam("mobile") String mobile) {
		Response response = null;
		ResponseBuilder builder = null;

		builder = Response.status(204);
		response = builder.build();
		return response;
	}

	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/transfer")
	public Response transfer(TransferDetails transferDetails) {
		Receipt receipt = null;
		Response response = null;
		ResponseBuilder builder = null;

		receipt = new Receipt();
		receipt.setReferenceNo(transferDetails.getFromAccount() + "-R");
		receipt.setStatus("success");

		builder = Response.ok();
		builder.header("app-id", "a303");
		builder.entity(receipt);
		response = builder.build();

		return response;
	}

	@PUT
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/login")
	public Response login(@FormParam("username") String username, @FormParam("password") String password) {
		NewCookie cookie = null;
		Response response = null;
		ResponseBuilder builder = null;

		if (username.equals("john") && password.equals("welcome1")) {
			cookie = new NewCookie("username", username);
			builder = Response.ok();
			builder.entity("Authentication Success");
			builder.cookie(cookie);
		} else {
			builder = Response.status(Status.BAD_GATEWAY);
			builder.entity("invalid un/pwd");
		}
		response = builder.build();
		return response;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/services")
	public Response getAvailableServices() {
		List<Service> services = null;
		Response response = null;
		ResponseBuilder builder = null;

		services = new ArrayList<Service>();
		services.add(new Service("opt-sms", false));
		services.add(new Service("check-book", true));

		builder = Response.ok();
		builder.entity(new GenericEntity<List<Service>>(services, List.class));
		response = builder.build();
		return response;
	}

	@GET
	@Produces(MediaType.APPLICATION_XML)
	@Path("/account/{acNo}")
	public Response getAccount(@PathParam("acNo") String accountNo) {
		Account account = null;
		Errors errors = null;

		errors = new Errors();
		if (accountNo == null || accountNo.trim().length() < 8) {
			errors.addError("001", "invalid field format");
		} else {
			try {
				if (accountNo.equals("ac000001")) {
					throw new Exception("account locked");
				}
				account = new Account();
				account.setAccountNo(accountNo);
				account.setAccountHolderName("john");
				account.setType("savings");
			} catch (Exception e) {
				errors.addError("002", "account locked");
			}
		}
		if (errors.hasErrors()) {
			return Response.status(Status.INTERNAL_SERVER_ERROR).entity(errors).build();
		}
		return Response.ok().entity(account).build();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/accountinfo/{acNo}")
	public Account getAccountInfo(@PathParam("acNo") String accountNo) {
		Account account = null;

		try {
			if (accountNo.equals("ac000001")) {
				throw new Exception("account locked");
			}
			account = new Account();
			account.setAccountNo(accountNo);
			account.setAccountHolderName("john");
			account.setType("savings");
		} catch (Exception e) {
			Errors errors = new Errors();
			errors.addError("002", "internal failure");
			throw new WebApplicationException(Response.serverError().entity(errors).build());
		}

		return account;
	}

	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/addCash/{accNo}/{amount}")
	public Receipt addCash(@PathParam("accNo") String accNo, @PathParam("amount") int amount) {
		if (accNo.equals("ac001")) {
			throw new AccountNotFoundException("account not found exception");
		}
		Receipt receipt = new Receipt();
		receipt.setReferenceNo(UUID.randomUUID().toString());
		receipt.setStatus("success");

		return receipt;
	}
}
