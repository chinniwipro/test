package com.sr.exception.mapper;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.sr.errors.Errors;
import com.sr.exception.AccountNotFoundException;

@Provider
public class AccountNotFoundExceptionMapper implements ExceptionMapper<AccountNotFoundException> {
	@Override
	public Response toResponse(AccountNotFoundException e) {
		Errors errors = new Errors();
		errors.addError("ac-100", "Account not available");
		return Response.status(Status.BAD_REQUEST).entity(errors).build();
	}

}
