package com.sr.errors;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "errors")
@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
public class Errors {
	protected List<Error> errors;

	public Errors() {
		errors = new ArrayList<>();
	}

	public void addError(String errorCode, String errorMessage) {
		Error error = new Error();
		error.setErrorCode(errorCode);
		error.setErrorMessage(errorMessage);
		errors.add(error);
	}

	public boolean hasErrors() {
		if (errors.size() > 0) {
			return true;
		}
		return false;
	}

}
