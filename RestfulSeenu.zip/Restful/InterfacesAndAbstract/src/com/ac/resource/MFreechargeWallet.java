package com.ac.resource;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.ws.rs.Path;

import com.ac.dto.Account;
import com.ac.exception.FreechargeFailure;

@Path("/m-freecharge")
public class MFreechargeWallet extends FreechargeWallet {

	@Override
	protected Account buildAccount(InputStream in) {
		int c = -1;
		String[] fields = null;
		Account account = null;
		StringBuffer buffer = null;

		try {
			buffer = new StringBuffer();
			while ((c = in.read()) != -1) {
				buffer.append((char) c);
			}
			in.close();
		} catch (IOException e) {
			throw new FreechargeFailure("unable to register", e);
		}
		fields = buffer.toString().split(",");
		account = new Account();
		account.setMobile(fields[0]);
		account.setAccountHolderName(fields[1]);

		return account;
	}

	@Override
	protected byte[] buildRegistrationResponse(Account account) {
		return account.getAccountNo().getBytes();
	}

}
