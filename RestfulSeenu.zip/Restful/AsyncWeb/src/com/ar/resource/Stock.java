package com.ar.resource;

import java.util.Random;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/stock")
public class Stock {
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/{stockName}/price")
	public void getStockQuote(@PathParam("stockName") final String stockName,
			@Suspended final AsyncResponse asyncResponse) {
		new Thread() {
			@Override
			public void run() {
				Random random = new Random(999999);
				asyncResponse.resume(Response.ok(random.nextInt()).build());
			}
		}.start();
	}
}
