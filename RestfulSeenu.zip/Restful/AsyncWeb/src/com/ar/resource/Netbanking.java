package com.ar.resource;

import java.util.Date;
import java.util.UUID;

import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.ar.dto.TransactionInfo;
import com.ar.dto.TransferInfo;

@Path("/netbanking")
public class Netbanking {
	@PUT
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	@Path("/transfer")
	public void transferFunds(final TransferInfo transferInfo, @Suspended final AsyncResponse asyncResponse) {
		new Thread() {
			@Override
			public void run() {
				TransactionInfo transactionInfo = new TransactionInfo();
				transactionInfo.setTransactionNo(UUID.randomUUID().toString());
				transactionInfo.setTransactionDate(new Date());
				transactionInfo.setStatus("success");

				asyncResponse.resume(Response.ok(transactionInfo).build());
			}
		}.start();
	}
}





