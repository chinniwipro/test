package com.rc.plan.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

public class PlanResourceClient {
	public static void main(String[] args) {
		ClientBuilder builder = ClientBuilder.newBuilder();
		builder.property("connection.timeout", "36000");

		Client client = builder.build();
		WebTarget target = client.target("http://localhost:8081/ResteasyFirstApplication/api/plan");
		target = target.queryParam("planNo", "13");
		Response response = target.request().get();
		if (response.getStatus() == 200) {
			String body = response.readEntity(String.class);
			System.out.println(body);
		}

	}
}
