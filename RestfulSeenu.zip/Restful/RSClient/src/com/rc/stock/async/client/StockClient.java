package com.rc.stock.async.client;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class StockClient {
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		List<String> stockNames = Arrays.asList(new String[] { "cipla", "ranbaxy", "icicdirect", "hdfc" });
		StockWatchList swl = new StockWatchList();
		swl.reloadCallback(stockNames);
	}
}
