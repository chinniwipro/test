package com.rc.stock.async.client;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.InvocationCallback;
import javax.ws.rs.core.Response;

public class StockWatchList {
	private final String BASE_URI = "http://localhost:8081/AsyncWeb/api/stock";

	public void reload(List<String> stockNames) throws InterruptedException, ExecutionException {
		List<Future<Response>> futures = null;

		futures = new ArrayList<Future<Response>>();
		for (int i = 0; i < stockNames.size(); i++) {
			Future<Response> future = ClientBuilder.newClient().target(BASE_URI).path("/{stockName}/price")
					.resolveTemplate("stockName", stockNames.get(i)).request().async().get();
			futures.add(future);
		}

		System.out.println("do something here");
		boolean isCompleted = true;
		do {
			isCompleted = true;
			for (int i = 0; i < futures.size(); i++) {
				Future<Response> future = futures.get(i);
				if (future.isDone()) {
					Response response = future.get();
					response.bufferEntity();
					Float price = response.readEntity(Float.class);
					System.out.println("price : " + price);
					futures.remove(i);
				} else {
					isCompleted = false;
				}
			}
		} while (isCompleted == false);
	}

	public void reloadCallback(List<String> stockNames) {

		for (int i = 0; i < stockNames.size(); i++) {
			ClientBuilder.newClient().target(BASE_URI).path("/{stockName}/price")
					.resolveTemplate("stockName", stockNames.get(i)).request().async()
					.get(new StockPriceCallbackHandler());
		}

	}

	private final class StockPriceCallbackHandler implements InvocationCallback<Response> {
		@Override
		public void completed(Response response) {
			Float price = response.readEntity(Float.class);
			System.out.println("updating in database price : " + price);
		}

		@Override
		public void failed(Throwable e) {
			e.printStackTrace();
		}

	}
}
