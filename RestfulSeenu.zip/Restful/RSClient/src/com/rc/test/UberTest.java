package com.rc.test;

import java.util.Date;

import com.cch.dto.AccountInfo;
import com.cch.dto.CabRequest;
import com.cch.dto.Membership;
import com.cch.dto.Trip;
import com.rc.uber.client.UberClient;

public class UberTest {
	public static void main(String[] args) {
		UberClient uClient = new UberClient();
		/*Membership memberShip = new Membership();
		memberShip.setFirstName("john");
		memberShip.setLastName("l");
		memberShip.setMobile("9389383");
		memberShip.setUsername("john");
		memberShip.setPassword("welcome1");
		
		AccountInfo accInfo = uClient.register(memberShip);
		System.out.println("account : "+ accInfo.getMemberNo());*/
		
		CabRequest cabRequest = new CabRequest();
		cabRequest.setMemberNo("m353");
		cabRequest.setSource("ameerpet");
		cabRequest.setDest("hitech city");
		cabRequest.setRequestDate(new Date());
		cabRequest.setCabType("mini");
		
		Trip trip = uClient.book(cabRequest);
		System.out.println("trip : "+ trip.getTripNo());
		
		
		
	}
}







