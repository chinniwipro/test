package com.rc.uber.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.cch.dto.AccountInfo;
import com.cch.dto.CabRequest;
import com.cch.dto.Membership;
import com.cch.dto.Trip;
import com.cch.readers.KeyValuedMessageBodyReader;
import com.cch.writers.KeyValuedMessageBodyWriter;

public class UberClient {
	private final String BASE_URI = "http://localhost:8081/CustomContentHandler/api/uber";

	public AccountInfo register(Membership memberShip) {
		AccountInfo accInfo = null;

		ClientBuilder builder = ClientBuilder.newBuilder();
		builder.register(KeyValuedMessageBodyReader.class);
		builder.register(KeyValuedMessageBodyWriter.class);

		Client client = builder.build();
		Response response = client.target(BASE_URI).request().post(Entity.entity(memberShip, MediaType.TEXT_PLAIN));
		if (response.getStatus() == Status.OK.getStatusCode()) {
			accInfo = response.readEntity(AccountInfo.class);
		}

		return accInfo;
	}

	public Trip book(CabRequest cabRequest) {
		Invocation invocation =  ClientBuilder.newClient().target(BASE_URI).path("/trip").request()
				.accept(MediaType.APPLICATION_XML).buildPost(Entity.json(cabRequest));
		Response response = invocation.invoke();
		Trip trip = response.readEntity(Trip.class);
		return trip;
	}

}







