package com.srl.resource;

import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.PUT;

public class SubscribedCustomerServicesCare {
	@PUT
	@Produces(MediaType.TEXT_PLAIN)
	public String active4G(@QueryParam("mobile") String mobile) {
		return "activated 4g on mobile : " + mobile;
	}
}
