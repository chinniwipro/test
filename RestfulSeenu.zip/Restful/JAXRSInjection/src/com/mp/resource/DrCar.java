package com.mp.resource;

import java.util.List;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.PathSegment;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import com.ji.bean.Criteria;

import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

@Path("/drCar")
public class DrCar {

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/{type}/{manuf}/{year}")
	public String search(@PathParam("type") String type, @PathParam("manuf") String manufacturer,
			@PathParam("year") int year, @MatrixParam("color") String color, @MatrixParam("fuel") String fuelType,
			@CookieParam("city") String city) {
		return "type : " + type + " manuf : " + manufacturer + " year : " + year + " color : " + color + " fuel : "
				+ fuelType + " city : " + city;
	}

	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/enquire/{name}/{mobile}")
	public String enquire(@PathParam("name") String name, @PathParam("mobile") String mobile,
			@DefaultValue("not available") @QueryParam("email") String email) {
		return "name : " + name + " mobile : " + mobile + " email : " + email;
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/quote/{model}/{manuf}/{year}")
	public String getQuote(@PathParam("model") PathSegment modelPathSeg, @PathParam("manuf") PathSegment manufPathSeg,
			@PathParam("year") int year) {
		String modelColor = null;
		String manufColor = null;

		modelColor = modelPathSeg.getMatrixParameters().getFirst("color");
		manufColor = manufPathSeg.getMatrixParameters().getFirst("color");

		return "model : " + modelPathSeg.getPath() + " color : " + modelColor + " manuf : " + manufPathSeg.getPath()
				+ "  color : " + manufColor + " year : " + year;
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/sales/{model}/{type}/report")
	public String saleReport(@PathParam("model") PathSegment model, @PathParam("type") PathSegment type) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("path : " + model.getPath());
		buffer.append(extract(model.getMatrixParameters()));
		buffer.append("path : ").append(type.getPath());
		buffer.append(extract(type.getMatrixParameters()));
		return buffer.toString();
	}

	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/add-car")
	public String addCar(@FormParam("modelNo") String modelNo, @FormParam("type") String type,
			@FormParam("manuf") String manufacturer, @FormParam("year") int year) {
		return "modelNo : " + modelNo + " type : " + type + " manuf : " + manufacturer + " year : " + year;
	}

	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/buy")
	public String reportBuy(@HeaderParam("agentNo") String agentNo, @FormParam("model") String model,
			@FormParam("type") String type) {
		return "agent : " + agentNo + "model : " + model + " type : " + type;
	}

	@Path("/clientId")
	@Produces(MediaType.TEXT_PLAIN)
	@GET
	public String getClientId(@HeaderParam("username") String username) {
		return "header : " + username;
	}

	@Path("/cookie")
	@POST
	@Produces(MediaType.TEXT_PLAIN)
	public Response createCityCookie() {
		NewCookie cookie = new NewCookie("city", "hyderbad");

		return Response.ok().cookie(cookie).build();
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/search/{manuf}/{type}")
	public String search(@BeanParam Criteria criteria) {
		return criteria.toString();
	}

	private String extract(MultivaluedMap<String, String> matrixParams) {
		StringBuffer buffer = new StringBuffer();

		for (String paramName : matrixParams.keySet()) {
			buffer.append(paramName).append(" : ");
			List<String> values = matrixParams.get(paramName);
			for (String value : values) {
				buffer.append(value + " ");
			}
			buffer.append(";");
		}

		return buffer.toString();
	}

}
