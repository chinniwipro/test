package com.fcw.common;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.fcw.resource.FreechargeWallet;

@ApplicationPath("/api")
public class FreechargeWalletApplication extends Application {
	private Set<Object> singletons;

	public FreechargeWalletApplication() {
		singletons = new HashSet<Object>();
		singletons.add(new FreechargeWallet());
	}

	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}

}
